% texmf-dist/tex/latex/foo/foo.lua from foo
\RequirePackage{baz}
